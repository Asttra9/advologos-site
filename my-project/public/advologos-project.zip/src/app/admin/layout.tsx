import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Painel Administrativo | Advologos',
  robots: { index: false, follow: false },
};

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[var(--grafite)] text-[var(--editorial)]">
      {/* Override grain overlay for cleaner admin view */}
      <style>{`
        body::before { display: none !important; }
      `}</style>
      {children}
    </div>
  );
}
