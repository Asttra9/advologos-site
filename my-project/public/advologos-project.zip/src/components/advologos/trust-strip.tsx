'use client';

import { useEffect, useRef } from 'react';
import { Scale, ShieldCheck, Zap, Award } from 'lucide-react';
import { ScrollReveal } from './scroll-reveal';

const TRUST_ITEMS = [
  {
    icon: Award,
    label: 'Branding Jurídico Especializado',
  },
  {
    icon: Scale,
    label: 'OAB Compliant',
  },
  {
    icon: ShieldCheck,
    label: 'Provimento 205/2021',
  },
  {
    icon: Zap,
    label: 'Sem dependência contínua',
  },
];

export function TrustStrip() {
  const stripRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const strip = stripRef.current;
    if (!strip) return;
    const onScroll = () => {
      const scrollY = window.scrollY;
      strip.style.transform = `translateY(${scrollY * -0.3}px)`;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div ref={stripRef} className="bg-[rgba(26,26,34,0.3)] border-y border-[rgba(184,196,204,0.06)] py-5 md:py-6 trust-strip-glow trust-strip-parallax trust-strip-bottom-line">
      <ScrollReveal>
        <div className="max-w-[1160px] mx-auto px-5 md:px-12">
          <div className="flex flex-col gap-3 md:gap-0 md:grid md:grid-cols-4">
            {TRUST_ITEMS.map((item, i) => (
              <div
                key={item.label}
                className={`trust-item-hover trust-item-glow trust-item-press flex items-center gap-2.5 px-3 py-2 md:px-0 md:py-0 ${
                  i < TRUST_ITEMS.length - 1
                    ? 'trust-divider-gradient md:pr-6'
                    : ''
                } ${i > 0 ? 'md:pl-6' : ''}`}
              >
                <span className="trust-icon-pulse flex-shrink-0">
                  <item.icon className="h-[14px] w-[14px] text-[var(--crimson-lt)]" />
                </span>
                <span className="text-[11px] sm:text-[11.5px] font-semibold tracking-[0.08em] uppercase text-[var(--nevoa)] leading-tight">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </ScrollReveal>
    </div>
  );
}
