import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const SESSION_COOKIE = 'advologos_admin_session';

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get(SESSION_COOKIE)?.value ?? null;

  // Token format check: 64-char hex string
  const tokenIsWellFormed = !!token && token.length === 64 && /^[0-9a-f]+$/.test(token);

  // Protect /api/admin/* routes (except /api/admin/auth which handles its own logic)
  if (pathname.startsWith('/api/admin') && !pathname.startsWith('/api/admin/auth')) {
    if (!tokenIsWellFormed) {
      return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 });
    }
    // Full session validation happens inside each API route handler via validateSession()
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*', '/api/admin/:path*'],
};
