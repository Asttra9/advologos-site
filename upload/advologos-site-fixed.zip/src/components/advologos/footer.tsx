import { NAV_LINKS, SITE_CONFIG, SOCIAL_LINKS } from '@/lib/constants';
import { AdvologosLogo } from './advologos-logo';
import { NewsletterSignup } from './newsletter-signup';
import { Instagram, Linkedin, Youtube } from 'lucide-react';

const ICON_MAP: Record<string, typeof Instagram> = {
  Instagram,
  Linkedin,
  Youtube,
};

export function Footer() {
  return (
    <footer className="mt-auto border-t border-[rgba(184,196,204,0.1)] footer-gradient-border" role="contentinfo">
      <div className="max-w-[1160px] mx-auto px-5 md:px-12 py-14">
        {/* Main footer content */}
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4 md:gap-8 mb-10">
          {/* Logo & tagline */}
          <div className="flex flex-col gap-3">
            <AdvologosLogo className="text-2xl" />
            <p className="text-[13px] text-[var(--prata)] leading-[1.65] max-w-[280px]">
              {SITE_CONFIG.description}
            </p>
          </div>

          {/* Navigation */}
          <div className="flex flex-col gap-3">
            <div className="text-[10px] font-bold tracking-[0.16em] uppercase text-[var(--crimson-lt)] mb-1">
              Navegação
            </div>
            <ul className="flex flex-col gap-2 list-none">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-[var(--nevoa)] no-underline text-[13px] font-medium tracking-[0.03em] transition-colors duration-300 hover:text-[var(--editorial)] hover:translate-x-1 inline-block"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#cta"
                  className="text-[var(--nevoa)] no-underline text-[13px] font-medium tracking-[0.03em] transition-colors duration-300 hover:text-[var(--editorial)] inline-block"
                >
                  Contato
                </a>
              </li>
              <li>
                <a
                  href="#faq"
                  className="text-[var(--nevoa)] no-underline text-[13px] font-medium tracking-[0.03em] transition-colors duration-300 hover:text-[var(--editorial)] inline-block"
                >
                  Perguntas frequentes
                </a>
              </li>
            </ul>
          </div>

          {/* Social links */}
          <div className="flex flex-col gap-3">
            <div className="text-[10px] font-bold tracking-[0.16em] uppercase text-[var(--crimson-lt)] mb-1">
              Redes Sociais
            </div>
            <div className="flex gap-4">
              {SOCIAL_LINKS.map((social) => {
                const IconComponent = ICON_MAP[social.icon];
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    className="flex flex-col items-center gap-1"
                  >
                    <span className="flex h-10 w-10 items-center justify-center rounded-full border border-[rgba(184,196,204,0.12)] bg-transparent text-[var(--nevoa)] hover:border-[var(--crimson)] hover:text-[var(--crimson-lt)] hover:bg-[rgba(139,30,45,0.08)] transition-all duration-300">
                      {IconComponent && <IconComponent className="h-4 w-4" />}
                    </span>
                    <span className="hidden md:block text-[9px] text-[var(--nevoa)] tracking-wide">
                      {social.followers}
                    </span>
                  </a>
                );
              })}
            </div>
            <p className="text-[11px] text-[var(--nevoa)] leading-[1.5] mt-1">
              Acompanhe nosso conteúdo sobre branding jurídico e posicionamento estratégico.
            </p>
          </div>

          {/* Newsletter */}
          <NewsletterSignup />
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-[rgba(184,196,204,0.06)] flex flex-col md:flex-row justify-between items-center gap-3">
          <small className="text-[10px] text-[var(--nevoa)] opacity-50 font-mono tracking-wide">
            © 2022 — 2026 {SITE_CONFIG.name}. Uso e aplicação sujeitos às diretrizes de marca.
          </small>
          <p className="text-[10px] text-[var(--nevoa)] opacity-40 tracking-wide">
            Marcas jurídicas com presença, clareza e autoridade.
          </p>
        </div>
      </div>
    </footer>
  );
}
