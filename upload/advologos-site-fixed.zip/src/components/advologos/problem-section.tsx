'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { ScrollReveal } from './scroll-reveal';

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
}

function AnimatedCounter({
  target,
  suffix = '',
  prefix = '',
  duration = 2000,
}: AnimatedCounterProps) {
  const [count, setCount] = useState(target);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  const animate = useCallback(() => {
    if (hasAnimated) return;
    setHasAnimated(true);
    setCount(0);

    const startTime = Date.now();
    const step = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * target));

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };
    requestAnimationFrame(step);
  }, [target, duration, hasAnimated]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animate();
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [animate]);

  return (
    <span ref={ref}>
      {prefix}
      {count}
      {suffix}
    </span>
  );
}

const STATS = [
  {
    display: '7s',
    target: 7,
    suffix: 's',
    title: 'Primeiros segundos são decisivos',
    description:
      'É o tempo que um potencial cliente leva para formar uma opinião sobre um escritório com base na identidade visual.',
  },
  {
    display: '3×',
    target: 3,
    suffix: '×',
    title: 'Percepção multiplica conversão',
    description:
      'Escritórios com identidade estruturada convertem até três vezes mais consultas em clientes do que os sem sistema de marca.',
  },
  {
    display: '92%',
    target: 92,
    suffix: '%',
    title: 'Decisão antes do primeiro contato',
    description:
      'A maioria dos clientes pesquisa o escritório online e já chega com uma opinião formada sobre competência antes de qualquer conversa.',
  },
];

function StatCard({ stat }: { stat: typeof STATS[number] }) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    el.style.setProperty('--mouse-x', `${x}%`);
    el.style.setProperty('--mouse-y', `${y}%`);
  }, []);

  const handleMouseLeave = useCallback(() => {
    const el = cardRef.current;
    if (!el) return;
    el.style.setProperty('--mouse-x', '50%');
    el.style.setProperty('--mouse-y', '50%');
  }, []);

  return (
    <div
      key={stat.display}
      className="bg-[rgba(255,255,255,0.025)] border border-[rgba(184,196,204,0.08)] p-1.25 rounded-[1.25rem] shimmer-on-hover card-glow"
    >
      <div
        ref={cardRef}
        className="glass-hover-card bg-[var(--ardosia)] rounded-[calc(1.25rem-5px)] shadow-[inset_0_1px_1px_rgba(255,255,255,0.06)] p-7 flex items-center gap-6"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <div className="font-serif text-[clamp(40px,5vw,56px)] font-normal text-[var(--crimson-lt)] leading-none tracking-[-0.02em] flex-shrink-0 relative z-[2]">
          <AnimatedCounter
            target={stat.target}
            suffix={stat.suffix}
          />
        </div>
        <div className="text-[14px] text-[var(--prata)] leading-[1.6] relative z-[2]">
          <strong className="block text-[var(--editorial)] text-[15px] font-semibold mb-1">
            {stat.title}
          </strong>
          {stat.description}
        </div>
      </div>
    </div>
  );
}

export function ProblemSection() {
  return (
    <section
      id="problema"
      className="py-20 border-b border-[rgba(184,196,204,0.08)] md:py-32 section-gradient-dark"
      aria-label="O problema"
    >
      <div className="max-w-[1160px] mx-auto px-5 md:px-12">
        <ScrollReveal>
          <div className="section-divider mb-14">
            <div className="section-divider-diamond" />
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 gap-12 items-center md:grid-cols-2 md:gap-20">
          {/* Left text */}
          <div>
            <ScrollReveal>
              <div className="inline-flex items-center gap-2.5 text-[10px] font-bold tracking-[0.18em] uppercase text-[var(--crimson-lt)] mb-5">
                <span className="block w-5 h-px bg-[var(--crimson-lt)] flex-shrink-0" />
                01 — O Problema
              </div>
            </ScrollReveal>

            <ScrollReveal delay={1}>
              <h2 className="section-heading-accent font-serif text-[clamp(32px,4.5vw,56px)] font-normal text-[var(--editorial)] leading-[1.08] tracking-[-0.015em] mb-5">
                Percepção é
                <br />
                precedente.
              </h2>
            </ScrollReveal>

            <ScrollReveal delay={2}>
              <p className="text-[var(--prata)] text-[15px] leading-[1.8] max-w-[620px]">
                No mercado jurídico, o cliente contrata quem parece mais competente, não necessariamente quem é. Uma marca inconsistente não é apenas um problema estético — é um problema de negócio.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={3}>
              <div className="bg-[rgba(139,30,45,0.07)] border border-[rgba(139,30,45,0.18)] rounded-lg p-5 mt-7 text-[13px] text-[var(--prata)] leading-[1.65]">
                <strong className="text-[var(--crimson-lt)]">A verdade inconveniente:</strong> um advogado brilhante com marca genérica compete em desvantagem com um colega mediano bem posicionado. A Advologos corrige essa equação — sem comprometer a ética profissional exigida pelo Provimento 205/2021 da OAB.
              </div>
            </ScrollReveal>
          </div>

          {/* Right stats */}
          <div className="flex flex-col gap-0.5">
            <ScrollReveal delay={2}>
              <div className="flex flex-col gap-2">
                {STATS.map((stat) => (
                  <StatCard key={stat.display} stat={stat} />
                ))}
              </div>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  );
}
