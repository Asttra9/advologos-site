'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { ScrollReveal } from './scroll-reveal';

interface StatItem {
  value: number;
  suffix: string;
  label: string;
}

const STATS: StatItem[] = [
  { value: 150, suffix: '+', label: 'Marcas entregues' },
  { value: 98, suffix: '%', label: 'Taxa de aprovação' },
  { value: 3, suffix: ' anos', label: 'De operação' },
  { value: 12, suffix: 'x', label: 'Média de retorno' },
];

function AnimatedStat({ target, suffix, duration = 2000 }: { target: number; suffix: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  const animate = useCallback(() => {
    if (hasAnimated) return;
    setHasAnimated(true);
    const startTime = Date.now();
    const step = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      // Use decimal precision during animation for smoother counting
      if (progress < 1) {
        setCount(parseFloat((eased * target).toFixed(1)));
      } else {
        setCount(Math.round(eased * target));
      }

      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, hasAnimated]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) { animate(); observer.unobserve(entry.target); }
        });
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [animate]);

  // Format display: show decimal during animation, integer when done
  const displayValue = hasAnimated && count === target
    ? Math.round(count)
    : parseFloat(count.toFixed(1));

  return <span ref={ref}>{displayValue}{suffix}</span>;
}

export function StatsRibbon() {
  return (
    <section className="relative py-8 border-y border-[rgba(184,196,204,0.08)] bg-[rgba(26,26,34,0.5)]" aria-label="Números da Advologos">
      <div className="max-w-[1160px] mx-auto px-5 md:px-12">
        <ScrollReveal>
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4 md:gap-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="stat-glow-border card-lift">
                <div className="flex flex-col items-center text-center gap-1 py-2 md:py-0">
                  <div className="font-serif text-[clamp(28px,4vw,40px)] text-[var(--crimson-lt)] leading-none tracking-[-0.02em]">
                    <AnimatedStat target={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="text-[10px] font-bold tracking-[0.14em] uppercase text-[var(--nevoa)]">
                    {stat.label}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
