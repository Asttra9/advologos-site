'use client';

const MARQUEE_ITEMS = [
  'Mendes & Associados',
  'Vasconcelos Advocacia',
  'Lemos Trabalhista',
  'Costa Jurídico',
  'Advogados BR',
  'Ferreira & Silva',
];

function LogoSet() {
  return (
    <>
      {MARQUEE_ITEMS.map((name) => (
        <span key={name} className="flex items-center gap-8 whitespace-nowrap">
          <span className="text-[14px] font-semibold tracking-[0.08em] uppercase text-[var(--nevoa)] opacity-40">
            {name}
          </span>
          <span className="text-[var(--nevoa)] opacity-20 text-[10px]">●</span>
        </span>
      ))}
    </>
  );
}

export function SocialProofMarquee() {
  return (
    <div
      id="numeros"
      aria-label="Resultados em Números"
      className="py-5 border-y border-[rgba(184,196,204,0.06)] overflow-hidden marquee-fade-mask"
    >
      <div className="marquee-track">
        <LogoSet />
        <LogoSet />
        <LogoSet />
        <LogoSet />
      </div>
    </div>
  );
}
