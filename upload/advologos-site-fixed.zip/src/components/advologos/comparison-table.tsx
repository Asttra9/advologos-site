'use client';

import { Check, ChevronRight } from 'lucide-react';
import { ScrollReveal } from './scroll-reveal';

const COMPARISON_FEATURES = [
  { name: 'Logo', signum: true, autoritas: true, imperium: true },
  { name: 'Paleta de Cores', signum: true, autoritas: true, imperium: true },
  { name: 'Tipografia', signum: true, autoritas: true, imperium: true },
  { name: 'Manual de Marca', signum: true, autoritas: true, imperium: true },
  { name: 'Papelaria', signum: false, autoritas: true, imperium: true },
  { name: 'Presença Digital', signum: false, autoritas: true, imperium: true },
  { name: 'Naming', signum: false, autoritas: false, imperium: true },
  { name: 'Estratégia de Posicionamento', signum: false, autoritas: false, imperium: true },
  { name: 'Reuniões de Alinhamento', signum: false, autoritas: false, imperium: true },
  { name: 'Suporte Pós-entrega', signum: false, autoritas: false, imperium: true },
];

function CheckCell({ included }: { included: boolean }) {
  if (included) {
    return (
      <span className="flex items-center justify-center">
        <Check className="h-[18px] w-[18px] text-[var(--crimson)]" strokeWidth={2.5} />
      </span>
    );
  }
  return (
    <span className="flex items-center justify-center text-[var(--nevoa)] text-[15px] select-none">
      —
    </span>
  );
}

function getFeatureCount(features: typeof COMPARISON_FEATURES, key: 'signum' | 'autoritas' | 'imperium') {
  return features.filter((f) => f[key]).length;
}

export function ComparisonTable() {
  const signumTotal = getFeatureCount(COMPARISON_FEATURES, 'signum');
  const autoritasTotal = getFeatureCount(COMPARISON_FEATURES, 'autoritas');
  const imperiumTotal = getFeatureCount(COMPARISON_FEATURES, 'imperium');

  return (
    <section
      id="comparativo"
      className="py-20 border-b border-[rgba(184,196,204,0.08)] md:py-32"
      aria-label="Comparativo de pacotes"
    >
      <div className="max-w-[1160px] mx-auto px-5 md:px-12">
        {/* Section header */}
        <ScrollReveal>
          <div className="inline-flex items-center gap-2.5 text-[10px] font-bold tracking-[0.18em] uppercase text-[var(--crimson-lt)] mb-5">
            <span className="block w-5 h-px bg-[var(--crimson-lt)] flex-shrink-0" />
            Comparativo
          </div>
        </ScrollReveal>

        <ScrollReveal delay={1}>
          <h2 className="section-heading-accent font-serif text-[clamp(32px,4.5vw,56px)] font-normal text-[var(--editorial)] leading-[1.08] tracking-[-0.015em] mb-5">
            Compare os pacotes
          </h2>
        </ScrollReveal>

        <ScrollReveal delay={2}>
          <p className="text-[var(--prata)] text-[15px] leading-[1.8] max-w-[620px] mb-14">
            Veja exatamente o que está incluído em cada nível de serviço. Escolha o pacote que corresponde ao momento da sua trajetória.
          </p>
        </ScrollReveal>

        {/* Table */}
        <ScrollReveal delay={3}>
          <div className="overflow-x-auto comparison-table-scroll -mx-5 md:-mx-12 px-5 md:px-12">
            <table className="w-full min-w-[560px] border-collapse">
              {/* Header */}
              <thead>
                <tr className="border-b border-[rgba(184,196,204,0.12)]">
                  <th className="text-left text-[11px] font-bold tracking-[0.14em] uppercase text-[var(--nevoa)] py-4 pr-4 pl-0 w-[200px]">
                    Recurso
                  </th>
                  <th className="text-center text-[11px] font-bold tracking-[0.14em] uppercase py-4 px-3">
                    <span className="text-[var(--prata)]">Signum</span>
                    <span className="block text-[9px] text-[var(--nevoa)] font-normal tracking-normal normal-case mt-0.5">Entrada</span>
                  </th>
                  <th className="text-center text-[11px] font-bold tracking-[0.14em] uppercase py-4 px-3 pt-8 rounded-t-xl comparison-featured-col relative">
                    {/* MAIS POPULAR badge — inline to avoid overflow clipping */}
                    <span className="inline-block text-[9px] font-bold tracking-[0.1em] uppercase bg-[linear-gradient(135deg,var(--crimson-dp),var(--crimson-lt))] text-[var(--editorial)] px-2.5 py-0.5 rounded-full whitespace-nowrap badge-shimmer shadow-[0_2px_8px_rgba(139,30,45,0.3)] mb-1.5">
                      Mais Popular
                    </span>
                    <span className="text-[var(--editorial)]">Autoritas</span>
                    <span className="block text-[9px] text-[var(--crimson-lt)] font-normal tracking-normal normal-case mt-0.5">Recomendado</span>
                  </th>
                  <th className="text-center text-[11px] font-bold tracking-[0.14em] uppercase py-4 px-3">
                    <span className="text-[var(--prata)]">Imperium</span>
                    <span className="block text-[9px] text-[var(--nevoa)] font-normal tracking-normal normal-case mt-0.5">Premium</span>
                  </th>
                </tr>
              </thead>

              {/* Body */}
              <tbody>
                {COMPARISON_FEATURES.map((feature, i) => (
                  <tr
                    key={feature.name}
                    className={`comparison-row border-b border-[rgba(184,196,204,0.06)] ${
                      i % 2 === 0 ? 'comparison-row-alt' : ''
                    }`}
                  >
                    <td className="text-[13px] text-[var(--prata-lt)] py-3.5 pr-4 pl-0 font-medium">
                      {feature.name}
                    </td>
                    <td className="py-3.5 px-3">
                      <CheckCell included={feature.signum} />
                    </td>
                    <td className="py-3.5 px-3 comparison-featured-cell comparison-featured-col">
                      <CheckCell included={feature.autoritas} />
                    </td>
                    <td className="py-3.5 px-3">
                      <CheckCell included={feature.imperium} />
                    </td>
                  </tr>
                ))}

                {/* Price row */}
                <tr className="border-b border-[rgba(184,196,204,0.12)] comparison-row">
                  <td className="text-[11px] font-bold tracking-[0.12em] uppercase text-[var(--nevoa)] pr-4 pl-0">
                    Preço
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="flex items-center justify-center text-[14px] font-semibold text-[var(--prata)]">
                      R$&nbsp;89,90
                    </span>
                  </td>
                  <td className="py-3.5 px-3 comparison-featured-cell comparison-featured-col">
                    <span className="flex flex-col items-center justify-center">
                      <span className="text-[14px] font-semibold text-[var(--crimson-lt)]">R$&nbsp;290</span>
                      <span className="text-[10px] text-[var(--nevoa)]">ou 6x de R$&nbsp;48,33/mês</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="flex flex-col items-center justify-center">
                      <span className="text-[14px] font-semibold text-[var(--prata)]">R$&nbsp;890</span>
                      <span className="text-[10px] text-[var(--nevoa)]">ou 12x de R$&nbsp;74,17/mês</span>
                    </span>
                  </td>
                </tr>

                {/* Total row */}
                <tr className="comparison-total-row">
                  <td className="text-[11px] font-bold tracking-[0.12em] uppercase text-[var(--nevoa)] pr-4 pl-0">
                    Total de recursos
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="flex items-center justify-center text-[16px] font-semibold text-[var(--prata)]">
                      {signumTotal}
                      <span className="text-[10px] font-normal text-[var(--nevoa)] ml-1">/ {COMPARISON_FEATURES.length}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-3 comparison-featured-cell comparison-featured-col">
                    <span className="flex items-center justify-center text-[16px] font-semibold text-[var(--crimson-lt)]">
                      {autoritasTotal}
                      <span className="text-[10px] font-normal text-[var(--nevoa)] ml-1">/ {COMPARISON_FEATURES.length}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="flex items-center justify-center text-[16px] font-semibold text-[var(--prata)]">
                      {imperiumTotal}
                      <span className="text-[10px] font-normal text-[var(--nevoa)] ml-1">/ {COMPARISON_FEATURES.length}</span>
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Mobile scroll indicator */}
          <div className="comparison-scroll-indicator">
            <span>Deslize para ver mais</span>
            <ChevronRight className="h-3 w-3" />
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
