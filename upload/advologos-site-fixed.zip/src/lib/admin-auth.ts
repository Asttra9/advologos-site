import { scryptSync, randomBytes, timingSafeEqual } from 'crypto';

/* ─── In-memory session store ─── */
interface Session {
  token: string;
  createdAt: number;
  expiresAt: number;
}

const sessions = new Map<string, Session>();

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const CLEANUP_INTERVAL_MS = 30 * 60 * 1000; // every 30 min

/* Periodically purge expired sessions */
setInterval(() => {
  const now = Date.now();
  for (const [token, session] of sessions) {
    if (session.expiresAt < now) sessions.delete(token);
  }
}, CLEANUP_INTERVAL_MS);

/* ─── Password hashing (scrypt with salt) ─── */
const SCRYPT_N = 16384; // CPU/memory cost
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEY_LEN = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, KEY_LEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
  return `${salt}:${hash.toString('hex')}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hashHex] = stored.split(':');
    if (!salt || !hashHex) return false;
    const hashBuf = Buffer.from(hashHex, 'hex');
    const candidate = scryptSync(password, salt, KEY_LEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
    return timingSafeEqual(hashBuf, candidate);
  } catch {
    return false;
  }
}

/* ─── Get the admin password hash from env ─── */
export function getAdminPasswordHash(): string {
  const stored = process.env.ADMIN_PASSWORD_HASH;
  if (!stored) {
    throw new Error(
      'ADMIN_PASSWORD_HASH não configurado. Defina a variável de ambiente antes de usar o painel admin.'
    );
  }
  return stored;
}

/* ─── Create a new session ─── */
export function createSession(): { token: string; cookieValue: string } {
  const token = randomBytes(32).toString('hex');
  const now = Date.now();
  sessions.set(token, {
    token,
    createdAt: now,
    expiresAt: now + SESSION_TTL_MS,
  });
  return { token, cookieValue: token };
}

/* ─── Validate a session token ─── */
export function validateSession(token: string | null): boolean {
  if (!token || token.length !== 64) return false;
  const session = sessions.get(token);
  if (!session) return false;
  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return false;
  }
  return true;
}

/* ─── Destroy a session ─── */
export function destroySession(token: string): void {
  sessions.delete(token);
}

/* ─── Cookie configuration ─── */
export const SESSION_COOKIE_NAME = 'advologos_admin_session';
export const SESSION_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: SESSION_TTL_MS / 1000,
};
