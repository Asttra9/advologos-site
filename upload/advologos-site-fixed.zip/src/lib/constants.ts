export const WHATSAPP_NUMBER = '5511958854229';
export const WHATSAPP_URL = 'https://wa.me/message/6MYA5WTYF5DEH1';

export const SITE_CONFIG = {
  name: 'Advologos',
  tagline: 'Marcas Jurídicas com Presença, Clareza e Autoridade',
  description:
    'A Advologos estrutura a forma como o mercado percebe quem advoga. Branding jurídico especializado com identidade visual, presença digital e autoridade de marca.',
  url: 'https://advologos.com.br',
  ogImage: '/og-image.jpg',
};

export const NAV_LINKS = [
  { href: '#problema', label: 'Por que' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#metodo', label: 'Método' },
  { href: '#autoridade', label: 'Autoridade' },
  { href: '#faq', label: 'FAQ' },
  { href: '#blog', label: 'Blog' },
  { href: '#resultados', label: 'Resultados' },
];

export interface ServiceItem {
  tier: string;
  name: string;
  meaning: string;
  description: string;
  items: string[];
  monthlyExtraItems?: string[];
  price: string;
  monthlyMonths?: number;
  featured?: boolean;
}

export const SERVICES: ServiceItem[] = [
  {
    tier: 'Entrada',
    name: 'Signum',
    meaning: '"A marca que te distingue"',
    description:
      'Identidade visual completa para profissionais que iniciam sua presença de marca no mercado jurídico. Fundação sólida, sem atalhos.',
    items: [
      'Logotipo e versões de aplicação',
      'Paleta de cores e tipografia',
      'Manual de identidade visual',
      'Assinatura de e-mail profissional',
      'Kit redes sociais (5 templates)',
    ],
    price: 'R$ 89,90',
  },
  {
    tier: 'Recomendado',
    name: 'Autoritas',
    meaning: '"A autoridade que se constrói"',
    description:
      'Branding completo com presença digital estruturada. Para profissionais que querem ser percebidos como referência em sua área de atuação.',
    featured: true,
    items: [
      'Tudo do Signum, expandido',
      'Site institucional 1 página',
      'Perfil Instagram estratégico',
      '30 templates de conteúdo',
      'Proposta comercial diagramada',
      'Cartão de visita + papelaria',
    ],
    monthlyExtraItems: [
      'Suporte mensal dedicado',
      'Atualizações de templates trimestrais',
      'Relatório de desempenho digital',
    ],
    price: 'R$ 290',
    monthlyMonths: 6,
  },
  {
    tier: 'Premium',
    name: 'Imperium',
    meaning: '"A presença que precede a conversa"',
    description:
      'Sistema completo de marca e presença digital para escritórios que precisam comunicar autoridade em múltiplos canais com consistência absoluta.',
    items: [
      'Tudo do Autoritas, ampliado',
      'Site completo multi-página',
      'Estratégia de conteúdo 90 dias',
      'Brand guidelines interativo',
      'Consultoria de posicionamento',
      'Suporte mensal 3 meses',
    ],
    monthlyExtraItems: [
      'Suporte prioritário contínuo',
      'Atualizações contínuas de conteúdo',
      'Consultoria trimestral de posicionamento',
      'Adaptação visual para novos canais',
    ],
    price: 'R$ 890',
    monthlyMonths: 12,
  },
];

export const METHOD_STEPS = [
  {
    num: '01',
    title: 'Diagnóstico de Percepção',
    text: 'Analisamos como o profissional é percebido hoje e como precisa ser percebido para atingir seus objetivos. A marca começa no problema de negócio, não no estilo.',
  },
  {
    num: '02',
    title: 'Estratégia de Posicionamento',
    text: 'Definimos o território de marca: área de atuação, público prioritário, diferencial competitivo e tom de voz. Tudo documentado antes do primeiro traço de design.',
  },
  {
    num: '03',
    title: 'Construção do Sistema Visual',
    text: 'Logotipo, cores, tipografia e elementos gráficos desenvolvidos como um sistema — não como peças isoladas. Cada decisão tem uma razão estrutural documentada.',
  },
  {
    num: '04',
    title: 'Aplicação e Presença Digital',
    text: 'A identidade é aplicada em todos os pontos de contato definidos no pacote: site, redes sociais, materiais impressos e templates operacionais.',
  },
  {
    num: '05',
    title: 'Entrega e Documentação',
    text: 'Brand guidelines completo, arquivos originais organizados e instruções de uso. A marca entregue é operável sem a Advologos — por design.',
  },
];

export const CHECKLIST_ITEMS = [
  'Alinhado ao Provimento 205/2021 da OAB',
  'Arquivos em formatos profissionais editáveis',
  'Manual de uso com todos os contextos mapeados',
  'Sistema pensado para escalar, não engavetar',
  'Sem dependência contínua de agência para operar',
  'Revisões documentadas e aprovação etapa por etapa',
];

export const TESTIMONIALS = [
  {
    quote:
      'Antes eu tinha um logo. Agora tenho uma marca que as pessoas reconhecem antes de eu falar qualquer coisa.',
    author: 'Dra. Marina Vasconcelos',
    role: 'Advogada Tributarista — São Paulo',
  },
  {
    quote:
      'O processo foi diferente de tudo que já contratei. Tinham uma razão para cada decisão — e as razões faziam sentido para o meu negócio.',
    author: 'Dr. Carlos Eduardo Mendes',
    role: 'Sócio Fundador — Mendes & Associados (Previdenciário)',
  },
  {
    quote:
      'Passei a cobrar honorários maiores depois do rebranding. Não porque aumentei os preços — porque parei de parecer genérico.',
    author: 'Dr. Thiago Lemos',
    role: 'Advogado Trabalhista — Rio de Janeiro',
  },
];

export const PILLARS = [
  {
    icon: 'scale' as const,
    title: 'Especialização jurídica',
    text: 'Conhecemos as restrições éticas, o vocabulário técnico e a forma como o cliente jurídico toma decisões. Não é nicho — é foco.',
  },
  {
    icon: 'diamond' as const,
    title: 'Sistemas, não peças',
    text: 'Entregamos identidades que funcionam em qualquer contexto, não logotipos bonitos que perdem coerência no segundo uso.',
  },
  {
    icon: 'triangle' as const,
    title: 'Método documentado',
    text: 'Cada decisão tem uma justificativa estratégica. O cliente recebe o raciocínio, não apenas o resultado — porque marca é decisão, não gosto.',
  },
];

export const BLOG_POSTS = [
  {
    category: 'Branding',
    title: 'Por que escritórios com marca estruturada cobram mais — e são escolhidos mais vezes',
    excerpt: 'A relação entre identidade visual e valor percebido no mercado jurídico. Dados e casos reais.',
    readTime: '5 min de leitura',
    date: '28 Mar 2026',
    slug: '#',
  },
  {
    category: 'Posicionamento',
    title: 'Provimento 205/2021: o que o advogado PODE fazer em publicidade',
    excerpt: 'Um guia prático sobre os limites e as oportunidades de comunicação permitidas pela OAB.',
    readTime: '7 min de leitura',
    date: '15 Mar 2026',
    slug: '#',
  },
  {
    category: 'Mercado Legal',
    title: 'Identidade visual não é logotipo — e por que essa confusão custa clientes',
    excerpt: 'A diferença entre um logo isolado e um sistema de marca que funciona em todos os pontos de contato.',
    readTime: '4 min de leitura',
    date: '02 Mar 2026',
    slug: '#',
  },
];

export const BEFORE_AFTER_CASES = [
  {
    client: 'Dra. Marina Vasconcelos',
    specialty: 'Tributarista — São Paulo',
    plan: 'Signum',
    metric: { value: '+340%', label: 'de visibilidade' },
    before: ['Logo genérico', 'Sem identidade visual', 'Instagram inconsistente', 'Site amador'],
    after: ['Marca estruturada', 'Identidade completa com guidelines', '30 templates estratégicos', 'Presença digital profissional'],
  },
  {
    client: 'Mendes & Associados',
    specialty: 'Previdenciário — Belo Horizonte',
    plan: 'Autoritas',
    metric: { value: '2×', label: 'contatos recebidos' },
    before: ['Brand book desatualizado', 'Zero posicionamento', 'Materiais sem padronização', 'Sem sistema visual'],
    after: ['Rebranding completo', 'Posicionamento documentado', 'Kit completo de materiais', 'Sistema visual escalável'],
  },
  {
    client: 'Dr. Thiago Lemos',
    specialty: 'Trabalhista — Rio de Janeiro',
    plan: 'Imperium',
    metric: { value: '+180%', label: 'de recall de marca' },
    before: ['Identidade improvisada', 'Sem presença digital', 'Sem proposta comercial', 'Percepção genérica'],
    after: ['Marca premium', 'Site multi-página + estratégia', 'Proposta comercial diagramada', 'Autoridade percebida no mercado'],
  },
];

export const SOCIAL_LINKS = [
  { icon: 'Instagram', href: 'https://www.instagram.com/advologos/', label: 'Instagram', followers: '12.5K' },
  { icon: 'Linkedin', href: '#', label: 'LinkedIn', followers: '8.2K' },
  { icon: 'Youtube', href: '#', label: 'YouTube', followers: '3.1K' },
];

export interface PortfolioProject {
  client: string;
  specialty: string;
  plan: string;
  category: string;
  description: string;
  results: string[];
  tags: string[];
  gradient: string;
}

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    client: 'Dra. Marina Vasconcelos',
    specialty: 'Advogada Tributarista — São Paulo',
    plan: 'Autoritas',
    category: 'Rebranding Completo',
    description: 'De marca genérica a referência reconhecida em direito tributário. Identidade visual, site e presença digital completamente estruturados.',
    results: ['+340% de visibilidade orgânica', '+85% de engajamento no Instagram', '2× mais contatos qualificados'],
    tags: ['Identidade Visual', 'Site Institucional', 'Social Media'],
    gradient: 'linear-gradient(135deg, rgba(139,30,45,0.25) 0%, rgba(26,26,34,0.95) 60%)',
  },
  {
    client: 'Mendes & Associados',
    specialty: 'Escritório Previdenciário — Belo Horizonte',
    plan: 'Imperium',
    category: 'Sistema de Marca',
    description: 'Sistema visual escalável para escritório de médio porte com múltiplas áreas de atuação e equipe de 12 advogados.',
    results: ['Sistema visual unificado', 'Brand guidelines interativo', '+200% de recall de marca'],
    tags: ['Sistema Visual', 'Brand Guidelines', 'Papelaria'],
    gradient: 'linear-gradient(135deg, rgba(165,37,53,0.2) 0%, rgba(13,13,15,0.95) 60%)',
  },
  {
    client: 'Dr. Thiago Lemos',
    specialty: 'Advogado Trabalhista — Rio de Janeiro',
    plan: 'Signum',
    category: 'Identidade Inicial',
    description: 'Fundação de marca sólida para advogado individual em fase de posicionamento no mercado trabalhista carioca.',
    results: ['Marca estruturada do zero', '30 templates de conteúdo', 'Presença digital profissional'],
    tags: ['Logotipo', 'Identidade Visual', 'Templates'],
    gradient: 'linear-gradient(135deg, rgba(107,21,32,0.22) 0%, rgba(26,26,34,0.95) 55%)',
  },
  {
    client: 'Costa Jurídico',
    specialty: 'Direito Empresarial — Curitiba',
    plan: 'Autoritas',
    category: 'Posicionamento Digital',
    description: 'Transição de escritório tradicional para presença digital estratégica. Estratégia de conteúdo e posicionamento documentados.',
    results: ['Estratégia de conteúdo 90 dias', 'Site de 1 página otimizado', '+180% de consultas online'],
    tags: ['Estratégia', 'Site', 'Posicionamento'],
    gradient: 'linear-gradient(135deg, rgba(139,30,45,0.18) 0%, rgba(20,20,28,0.95) 65%)',
  },
  {
    client: 'Lemos Trabalhista',
    specialty: 'Direito Trabalhista — Niterói',
    plan: 'Autoritas',
    category: 'Rebranding + Digital',
    description: 'Rebranding total com foco em presença digital para escritório especializado em direito do trabalho.',
    results: ['Rebranding completo', 'Perfil Instagram estratégico', 'Proposta comercial diagramada'],
    tags: ['Rebranding', 'Instagram', 'Proposta Comercial'],
    gradient: 'linear-gradient(135deg, rgba(139,30,45,0.2) 0%, rgba(22,22,30,0.95) 55%)',
  },
  {
    client: 'Ferreira & Sobreira',
    specialty: 'Direito Civil — Salvador',
    plan: 'Imperium',
    category: 'Marca Premium',
    description: 'Construção de marca premium para escritório boutique com foco em alto padrão. Identidade sofisticada e consultoria de posicionamento.',
    results: ['Marca premium posicionada', 'Consultoria de posicionamento', 'Suporte mensal 3 meses'],
    tags: ['Marca Premium', 'Consultoria', 'Identidade Visual'],
    gradient: 'linear-gradient(135deg, rgba(165,37,53,0.15) 0%, rgba(18,18,24,0.95) 60%)',
  },
];

export const FAQ_ITEMS = [
  {
    question: 'Preciso ter um escritório grande para contratar a Advologos?',
    answer: 'Não. Trabalhamos com advogados individualmente, sócios de escritórios de médio porte e grandes firmas. O que muda é a escala do projeto, não a qualidade da entrega. Nosso pacote Signum foi criado exatamente para profissionais que estão construindo sua presença de marca.',
  },
  {
    question: 'O trabalho da Advologos respeita as regras da OAB?',
    answer: 'Integralmente. Todo nosso trabalho segue o Provimento 205/2021 do Conselho Federal da OAB, que regulamenta a publicidade na advocacia. Não utilizamos mercantilização indevida, captação de clientela ou promessas de resultados. Branding é comunicação de identidade — e isso é permitido e incentivado pelo Provimento.',
  },
  {
    question: 'Quanto tempo leva um projeto de branding?',
    answer: 'Depende do pacote contratado. O Signum leva em média 2 semanas. O Autoritas, de 3 a 4 semanas. O Imperium, de 5 a 6 semanas. Cada etapa é documentada e passível de aprovação — não há surpresas no processo.',
  },
  {
    question: 'A Advologos cria conteúdo para redes sociais?',
    answer: 'Criamos templates estratégicos e guias de conteúdo que você (ou seu time) pode usar de forma consistente. Não somos uma agência de social media — somos especialistas em marca. A diferença é que nossos templates são construídos sobre um sistema visual coerente, não sobre tendências passageiras.',
  },
  {
    question: 'Posso migrar de um pacote para outro durante o projeto?',
    answer: 'Sim. Se durante o projeto você perceber que precisa de mais alcance, é possível migrar para um pacote superior. O valor já investido é abatido proporcionalmente. Não fazemos upgrade forçado — a decisão é sempre do cliente.',
  },
  {
    question: 'O que acontece se eu não gostar de uma entrega?',
    answer: 'Cada etapa do projeto tem revisões documentadas. Apresentamos o raciocínio estratégico por trás de cada decisão — porque marca é decisão, não gosto. Se algo não atender ao briefing, revisamos com base no documento de posicionamento aprovado. Em três anos de operação, nunca tivemos um projeto não finalizado.',
  },
];
